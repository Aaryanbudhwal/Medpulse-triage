import { notFound } from "next/navigation";
import { MapPin, Phone } from "lucide-react";
import { getHospitalById } from "@/lib/data/hospitals";
import { bedTypeLabels, bedTypeDescriptions } from "@/lib/utils";
import ReserveBedForm from "@/components/reserve-bed-form";

export default async function HospitalDetailPage({ params }: { params: Promise<{ hospitalId: string }> }) {
  const { hospitalId } = await params;
  const hospital = await getHospitalById(hospitalId);
  if (!hospital) notFound();

  return (
    <div className="mx-auto max-w-3xl px-6 py-12">
      <h1 className="font-display text-3xl font-medium text-foreground">{hospital.name}</h1>
      <div className="mt-2 flex flex-wrap gap-x-5 gap-y-1 text-sm text-muted-foreground">
        <span className="flex items-center gap-1.5">
          <MapPin className="h-3.5 w-3.5" /> {hospital.address}, {hospital.city}
        </span>
        {hospital.phone && (
          <span className="flex items-center gap-1.5">
            <Phone className="h-3.5 w-3.5" /> {hospital.phone}
          </span>
        )}
      </div>

      <div className="mt-8 space-y-4">
        {hospital.beds.map((bed) => (
          <div key={bed.id} className="rounded-2xl border border-card-border bg-card p-6">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <p className="font-display text-xl font-medium text-foreground">{bedTypeLabels[bed.type]}</p>
                <p className="mt-1 text-sm text-muted-foreground">{bedTypeDescriptions[bed.type]}</p>
              </div>
              <div className="text-right">
                <p
                  className={`font-display text-2xl font-medium ${
                    bed.availableCount > 0 ? "text-success" : "text-muted-foreground"
                  }`}
                >
                  {bed.availableCount}
                  <span className="text-base text-muted-foreground"> / {bed.totalCount}</span>
                </p>
                <p className="text-xs text-muted-foreground">available now</p>
              </div>
            </div>

            <div className="mt-4">
              <ReserveBedForm bedId={bed.id} hospitalId={hospital.id} disabled={bed.availableCount === 0} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
