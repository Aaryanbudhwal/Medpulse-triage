import { redirect } from "next/navigation";
import { AlertCircle, Phone } from "lucide-react";
import { auth } from "@/lib/auth";
import { getHospitalByAdminId } from "@/lib/data/hospitals";
import { listReservationsForHospital } from "@/lib/data/reservations";
import { updateBedCounts, updateReservationStatus } from "@/lib/actions/beds";
import { bedTypeLabels, formatDateTime } from "@/lib/utils";
import StatusBadge from "@/components/status-badge";
import ActionButton from "@/components/action-button";
import SubmitButton from "@/components/submit-button";
import type { BedType } from "@/lib/db";

const bedTypeOrder: BedType[] = ["ICU", "GENERAL", "VENTILATOR", "OXYGEN"];

export default async function HospitalAdminPage() {
  const session = await auth();
  if (!session || session.user.role !== "HOSPITAL_ADMIN") redirect("/login");

  const hospital = await getHospitalByAdminId(session.user.id);
  if (!hospital) {
    return (
      <div className="mx-auto max-w-2xl px-6 py-16 text-center text-muted-foreground">
        No hospital profile found for this account.
      </div>
    );
  }

  const reservations = await listReservationsForHospital(hospital.id);
  const pending = reservations.filter((r) => r.status === "PENDING");
  const active = reservations.filter((r) => r.status === "CONFIRMED");
  const history = reservations.filter((r) => !["PENDING", "CONFIRMED"].includes(r.status));

  const bedByType = new Map(hospital.beds.map((b) => [b.type, b]));

  return (
    <div className="mx-auto max-w-4xl px-6 py-12">
      <h1 className="font-display text-3xl font-medium text-foreground">{hospital.name}</h1>
      <p className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
        {hospital.address}, {hospital.city}
        {hospital.phone && (
          <span className="ml-3 flex items-center gap-1">
            <Phone className="h-3.5 w-3.5" /> {hospital.phone}
          </span>
        )}
      </p>

      <section className="mt-8 rounded-2xl border border-card-border bg-card p-6">
        <h2 className="font-display text-xl font-medium text-foreground">Bed inventory</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Set the total beds you have of each type, and how many are available right now.
        </p>

        <form action={updateBedCounts.bind(null, hospital.id)} className="mt-5 space-y-4">
          <div className="grid gap-3 sm:grid-cols-2">
            {bedTypeOrder.map((type) => {
              const bed = bedByType.get(type);
              return (
                <div key={type} className="rounded-xl bg-muted p-4">
                  <p className="text-sm font-medium text-foreground">{bedTypeLabels[type]}</p>
                  <div className="mt-2 flex items-center gap-3">
                    <label className="flex-1 text-xs text-muted-foreground">
                      Total
                      <input
                        type="number"
                        min={0}
                        name={`total_${type}`}
                        defaultValue={bed?.totalCount ?? 0}
                        className="mt-1 w-full rounded-lg border border-card-border bg-card px-3 py-1.5 text-sm outline-none focus:border-primary"
                      />
                    </label>
                    <label className="flex-1 text-xs text-muted-foreground">
                      Available
                      <input
                        type="number"
                        min={0}
                        name={`available_${type}`}
                        defaultValue={bed?.availableCount ?? 0}
                        className="mt-1 w-full rounded-lg border border-card-border bg-card px-3 py-1.5 text-sm outline-none focus:border-primary"
                      />
                    </label>
                  </div>
                </div>
              );
            })}
          </div>
          <SubmitButton pendingText="Saving…">Save bed counts</SubmitButton>
        </form>
      </section>

      <section className="mt-8 rounded-2xl border border-card-border bg-card p-6">
        <h2 className="font-display text-xl font-medium text-foreground">
          Pending requests {pending.length > 0 && <span className="text-muted-foreground">({pending.length})</span>}
        </h2>

        {pending.length === 0 ? (
          <p className="mt-3 text-sm text-muted-foreground">No pending requests right now.</p>
        ) : (
          <ul className="mt-4 space-y-3">
            {pending.map((r) => (
              <li key={r.id} className="rounded-xl border border-card-border p-4">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-foreground">{r.patientName}</p>
                      {r.patientAge && <span className="text-xs text-muted-foreground">Age {r.patientAge}</span>}
                      {r.isEmergency && (
                        <span className="flex items-center gap-1 rounded-full bg-accent-soft px-2 py-0.5 text-xs font-medium text-accent">
                          <AlertCircle className="h-3 w-3" /> Emergency
                        </span>
                      )}
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">
                      {bedTypeLabels[r.bedType]} bed · {r.contactPhone}
                    </p>
                    {r.notes && <p className="mt-1 text-sm text-muted-foreground">&ldquo;{r.notes}&rdquo;</p>}
                    <p className="mt-1 text-xs text-muted-foreground">{formatDateTime(r.createdAt)}</p>
                  </div>
                  <div className="flex gap-2">
                    <ActionButton
                      action={updateReservationStatus.bind(null, r.id, "REJECTED")}
                      label="Reject"
                      variant="danger"
                      confirmText="Reject this reservation request?"
                    />
                    <ActionButton
                      action={updateReservationStatus.bind(null, r.id, "CONFIRMED")}
                      label="Confirm"
                      variant="primary"
                    />
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      {active.length > 0 && (
        <section className="mt-8 rounded-2xl border border-card-border bg-card p-6">
          <h2 className="font-display text-xl font-medium text-foreground">Currently admitted</h2>
          <ul className="mt-4 space-y-3">
            {active.map((r) => (
              <li key={r.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-card-border p-4">
                <div>
                  <p className="font-medium text-foreground">{r.patientName}</p>
                  <p className="text-sm text-muted-foreground">{bedTypeLabels[r.bedType]} bed · {r.contactPhone}</p>
                </div>
                <ActionButton
                  action={updateReservationStatus.bind(null, r.id, "COMPLETED")}
                  label="Mark discharged"
                  variant="outline"
                  confirmText="Mark this patient as discharged and free the bed?"
                />
              </li>
            ))}
          </ul>
        </section>
      )}

      {history.length > 0 && (
        <section className="mt-8 rounded-2xl border border-card-border bg-card p-6">
          <h2 className="font-display text-xl font-medium text-foreground">History</h2>
          <ul className="mt-4 space-y-2">
            {history.map((r) => (
              <li key={r.id} className="flex flex-wrap items-center justify-between gap-3 border-b border-card-border py-2.5 last:border-0">
                <div>
                  <p className="text-sm font-medium text-foreground">{r.patientName}</p>
                  <p className="text-xs text-muted-foreground">{bedTypeLabels[r.bedType]} · {formatDateTime(r.createdAt)}</p>
                </div>
                <StatusBadge status={r.status} />
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
