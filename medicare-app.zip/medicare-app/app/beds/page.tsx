import Link from "next/link";
import { MapPin, ArrowRight, SearchX } from "lucide-react";
import { listHospitals } from "@/lib/data/hospitals";
import { bedTypeLabels } from "@/lib/utils";
import type { BedType } from "@/lib/db";

const bedTypeOptions: BedType[] = ["ICU", "GENERAL", "VENTILATOR", "OXYGEN"];

export default async function BedsPage({
  searchParams,
}: {
  searchParams: Promise<{ city?: string; type?: string }>;
}) {
  const params = await searchParams;
  const city = params.city?.trim() || undefined;
  const bedType = (params.type as BedType | undefined) || undefined;

  const hospitals = await listHospitals({ city, bedType });

  return (
    <div className="mx-auto max-w-6xl px-6 py-12">
      <h1 className="font-display text-3xl font-medium text-foreground">Hospitals &amp; bed availability</h1>
      <p className="mt-2 text-muted-foreground">Live counts, updated by each hospital&apos;s admin team.</p>

      <form className="mt-8 flex flex-wrap items-end gap-4 rounded-2xl border border-card-border bg-card p-5">
        <div className="min-w-[200px] flex-1">
          <label className="mb-1.5 block text-sm font-medium text-foreground" htmlFor="city">
            City
          </label>
          <input
            id="city"
            name="city"
            defaultValue={city}
            placeholder="e.g. Agra"
            className="w-full rounded-xl border border-card-border px-4 py-2.5 text-sm outline-none focus:border-primary"
          />
        </div>
        <div className="min-w-[200px] flex-1">
          <label className="mb-1.5 block text-sm font-medium text-foreground" htmlFor="type">
            Bed type
          </label>
          <select
            id="type"
            name="type"
            defaultValue={bedType ?? ""}
            className="w-full rounded-xl border border-card-border bg-card px-4 py-2.5 text-sm outline-none focus:border-primary"
          >
            <option value="">Any</option>
            {bedTypeOptions.map((t) => (
              <option key={t} value={t}>
                {bedTypeLabels[t]}
              </option>
            ))}
          </select>
        </div>
        <button
          type="submit"
          className="rounded-full bg-primary px-6 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90"
        >
          Search
        </button>
      </form>

      {hospitals.length === 0 ? (
        <div className="mt-14 flex flex-col items-center gap-3 text-center text-muted-foreground">
          <SearchX className="h-8 w-8" />
          <p>No hospitals match that search. Try a different city or bed type.</p>
        </div>
      ) : (
        <ul className="mt-8 grid gap-4 sm:grid-cols-2">
          {hospitals.map((h) => (
            <li key={h.id}>
              <Link
                href={`/beds/${h.id}`}
                className="flex h-full flex-col rounded-2xl border border-card-border bg-card p-6 hover:border-primary"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-display text-lg font-medium text-foreground">{h.name}</p>
                    <p className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
                      <MapPin className="h-3.5 w-3.5" /> {h.city}
                    </p>
                  </div>
                  <ArrowRight className="mt-1 h-4 w-4 shrink-0 text-muted-foreground" />
                </div>

                <div className="mt-5 flex flex-wrap gap-2">
                  {h.beds.map((b) => (
                    <span
                      key={b.id}
                      className={`rounded-full px-3 py-1 text-xs font-medium ${
                        b.availableCount > 0 ? "bg-success-soft text-success" : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {bedTypeLabels[b.type]}: {b.availableCount}/{b.totalCount}
                    </span>
                  ))}
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
