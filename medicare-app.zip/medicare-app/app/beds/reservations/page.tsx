import Link from "next/link";
import { redirect } from "next/navigation";
import { BedSingle, MapPin, AlertCircle } from "lucide-react";
import { auth } from "@/lib/auth";
import { listReservationsForPatient } from "@/lib/data/reservations";
import { cancelReservation } from "@/lib/actions/beds";
import { bedTypeLabels, formatDateTime } from "@/lib/utils";
import StatusBadge from "@/components/status-badge";
import CancelButton from "@/components/cancel-button";

export default async function MyReservationsPage({
  searchParams,
}: {
  searchParams: Promise<{ requested?: string }>;
}) {
  const session = await auth();
  if (!session) redirect("/login");

  const { requested } = await searchParams;
  const reservations = await listReservationsForPatient(session.user.id);

  return (
    <div className="mx-auto max-w-3xl px-6 py-12">
      <h1 className="font-display text-3xl font-medium text-foreground">My bed reservations</h1>
      <p className="mt-2 text-muted-foreground">Requests you&apos;ve sent to hospitals.</p>

      {requested === "1" && (
        <p className="mt-6 rounded-xl bg-success-soft px-4 py-3 text-sm text-success">
          Request sent. The hospital will confirm or reject it shortly.
        </p>
      )}

      {reservations.length === 0 ? (
        <div className="mt-10 rounded-2xl border border-dashed border-card-border p-10 text-center text-muted-foreground">
          <p>No reservations yet.</p>
          <Link href="/beds" className="mt-3 inline-block font-medium text-primary hover:underline">
            Browse hospitals
          </Link>
        </div>
      ) : (
        <ul className="mt-8 space-y-4">
          {reservations.map((r) => (
            <li key={r.id} className="rounded-2xl border border-card-border bg-card p-5">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <BedSingle className="h-4 w-4 text-primary" />
                    <p className="font-medium text-foreground">{bedTypeLabels[r.bedType]} bed</p>
                    {r.isEmergency && (
                      <span className="flex items-center gap-1 rounded-full bg-accent-soft px-2 py-0.5 text-xs font-medium text-accent">
                        <AlertCircle className="h-3 w-3" /> Emergency
                      </span>
                    )}
                  </div>
                  <p className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
                    <MapPin className="h-3.5 w-3.5" /> {r.hospitalName}, {r.hospitalCity}
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">Requested {formatDateTime(r.createdAt)}</p>
                </div>

                <div className="flex flex-col items-end gap-2">
                  <StatusBadge status={r.status} />
                  {(r.status === "PENDING" || r.status === "CONFIRMED") && (
                    <CancelButton
                      action={cancelReservation.bind(null, r.id)}
                      confirmText="Cancel this bed reservation?"
                    />
                  )}
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
