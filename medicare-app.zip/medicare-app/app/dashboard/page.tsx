import Link from "next/link";
import { redirect } from "next/navigation";
import { BedSingle, CalendarCheck } from "lucide-react";
import { auth } from "@/lib/auth";

export default async function DashboardPage() {
  const session = await auth();
  if (!session) redirect("/login");

  if (session.user.role === "HOSPITAL_ADMIN") redirect("/beds/admin");
  if (session.user.role === "DOCTOR") redirect("/doctors/admin");

  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <h1 className="font-display text-3xl font-medium text-foreground">
        Hi {(session.user.name ?? "there").split(" ")[0]}
      </h1>
      <p className="mt-2 text-muted-foreground">What would you like to do?</p>

      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        <Link
          href="/beds/reservations"
          className="flex items-center gap-4 rounded-2xl border border-card-border bg-card p-6 hover:border-primary"
        >
          <span className="flex h-11 w-11 items-center justify-center rounded-full bg-primary-soft text-primary">
            <BedSingle className="h-5 w-5" />
          </span>
          <div>
            <p className="font-medium text-foreground">My bed reservations</p>
            <p className="text-sm text-muted-foreground">View or cancel requests</p>
          </div>
        </Link>

        <Link
          href="/doctors/appointments"
          className="flex items-center gap-4 rounded-2xl border border-card-border bg-card p-6 hover:border-primary"
        >
          <span className="flex h-11 w-11 items-center justify-center rounded-full bg-primary-soft text-primary">
            <CalendarCheck className="h-5 w-5" />
          </span>
          <div>
            <p className="font-medium text-foreground">My appointments</p>
            <p className="text-sm text-muted-foreground">View or cancel bookings</p>
          </div>
        </Link>
      </div>
    </div>
  );
}
