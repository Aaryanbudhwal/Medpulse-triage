import { notFound } from "next/navigation";
import { MapPin, Stethoscope, IndianRupee } from "lucide-react";
import { getDoctorById, listBookableSlots } from "@/lib/data/doctors";
import BookAppointmentForm from "@/components/book-appointment-form";

export default async function DoctorDetailPage({ params }: { params: Promise<{ doctorId: string }> }) {
  const { doctorId } = await params;
  const doctor = await getDoctorById(doctorId);
  if (!doctor) notFound();

  const slots = await listBookableSlots(doctorId);

  return (
    <div className="mx-auto max-w-2xl px-6 py-12">
      <h1 className="font-display text-3xl font-medium text-foreground">{doctor.name}</h1>
      <div className="mt-2 flex flex-wrap gap-x-5 gap-y-1 text-sm text-muted-foreground">
        <span className="flex items-center gap-1.5 text-primary">
          <Stethoscope className="h-3.5 w-3.5" /> {doctor.specialty}
        </span>
        <span className="flex items-center gap-1.5">
          <MapPin className="h-3.5 w-3.5" /> {doctor.clinicName}, {doctor.city}
        </span>
        {doctor.consultationFee != null && (
          <span className="flex items-center gap-1">
            <IndianRupee className="h-3.5 w-3.5" /> {doctor.consultationFee} consultation
          </span>
        )}
      </div>

      {doctor.bio && <p className="mt-4 text-sm text-muted-foreground">{doctor.bio}</p>}
      <p className="mt-1 text-xs text-muted-foreground">{doctor.address}</p>

      <div className="mt-8 rounded-2xl border border-card-border bg-card p-6">
        <h2 className="font-display text-xl font-medium text-foreground">Book an appointment</h2>
        <p className="mt-1 text-sm text-muted-foreground">Pick a time slot below.</p>
        <div className="mt-5">
          <BookAppointmentForm doctorId={doctor.id} slots={slots} />
        </div>
      </div>
    </div>
  );
}
