import { redirect } from "next/navigation";
import { MapPin } from "lucide-react";
import { auth } from "@/lib/auth";
import { getDoctorByUserId, listUpcomingSlotsForAdmin } from "@/lib/data/doctors";
import { listAppointmentsForDoctor } from "@/lib/data/appointments";
import { removeDoctorSlot, markAppointmentCompleted } from "@/lib/actions/doctors";
import { formatDateTime } from "@/lib/utils";
import StatusBadge from "@/components/status-badge";
import ActionButton from "@/components/action-button";
import AddSlotsForm from "@/components/add-slots-form";

export default async function DoctorAdminPage() {
  const session = await auth();
  if (!session || session.user.role !== "DOCTOR") redirect("/login");

  const doctor = await getDoctorByUserId(session.user.id);
  if (!doctor) {
    return (
      <div className="mx-auto max-w-2xl px-6 py-16 text-center text-muted-foreground">
        No doctor profile found for this account.
      </div>
    );
  }

  const [slots, appointments] = await Promise.all([
    listUpcomingSlotsForAdmin(doctor.id),
    listAppointmentsForDoctor(doctor.id),
  ]);

  const upcoming = appointments.filter((a) => a.status === "CONFIRMED");
  const history = appointments.filter((a) => a.status !== "CONFIRMED");

  return (
    <div className="mx-auto max-w-4xl px-6 py-12">
      <h1 className="font-display text-3xl font-medium text-foreground">{doctor.name}</h1>
      <p className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
        <MapPin className="h-3.5 w-3.5" /> {doctor.clinicName}, {doctor.city}
      </p>

      <section className="mt-8 rounded-2xl border border-card-border bg-card p-6">
        <h2 className="font-display text-xl font-medium text-foreground">Open new slots</h2>
        <p className="mt-1 text-sm text-muted-foreground">Add a block of time and it'll be split into slots.</p>
        <div className="mt-5">
          <AddSlotsForm />
        </div>
      </section>

      <section className="mt-8 rounded-2xl border border-card-border bg-card p-6">
        <h2 className="font-display text-xl font-medium text-foreground">Upcoming slots</h2>
        {slots.length === 0 ? (
          <p className="mt-3 text-sm text-muted-foreground">No upcoming slots. Add some above.</p>
        ) : (
          <ul className="mt-4 flex flex-wrap gap-2">
            {slots.map((slot) => (
              <li
                key={slot.id}
                className={`flex items-center gap-2 rounded-full border px-3 py-1.5 text-sm ${
                  slot.isBooked ? "border-card-border bg-muted text-muted-foreground" : "border-card-border text-foreground"
                }`}
              >
                {formatDateTime(slot.startTime)}
                {slot.isBooked ? (
                  <span className="text-xs">Booked</span>
                ) : (
                  <ActionButton
                    action={removeDoctorSlot.bind(null, slot.id)}
                    label="Remove"
                    variant="danger"
                    confirmText="Remove this open slot?"
                  />
                )}
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="mt-8 rounded-2xl border border-card-border bg-card p-6">
        <h2 className="font-display text-xl font-medium text-foreground">
          Upcoming appointments {upcoming.length > 0 && <span className="text-muted-foreground">({upcoming.length})</span>}
        </h2>
        {upcoming.length === 0 ? (
          <p className="mt-3 text-sm text-muted-foreground">No booked appointments yet.</p>
        ) : (
          <ul className="mt-4 space-y-3">
            {upcoming.map((a) => (
              <li key={a.id} className="flex flex-wrap items-start justify-between gap-4 rounded-xl border border-card-border p-4">
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-foreground">{a.patientName}</p>
                    {a.patientAge && <span className="text-xs text-muted-foreground">Age {a.patientAge}</span>}
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">{a.contactPhone}</p>
                  {a.reason && <p className="mt-1 text-sm text-muted-foreground">&ldquo;{a.reason}&rdquo;</p>}
                  <p className="mt-1 text-sm font-medium text-foreground">{formatDateTime(a.startTime)}</p>
                </div>
                <ActionButton
                  action={markAppointmentCompleted.bind(null, a.id)}
                  label="Mark completed"
                  variant="primary"
                />
              </li>
            ))}
          </ul>
        )}
      </section>

      {history.length > 0 && (
        <section className="mt-8 rounded-2xl border border-card-border bg-card p-6">
          <h2 className="font-display text-xl font-medium text-foreground">History</h2>
          <ul className="mt-4 space-y-2">
            {history.map((a) => (
              <li key={a.id} className="flex flex-wrap items-center justify-between gap-3 border-b border-card-border py-2.5 last:border-0">
                <div>
                  <p className="text-sm font-medium text-foreground">{a.patientName}</p>
                  <p className="text-xs text-muted-foreground">{formatDateTime(a.startTime)}</p>
                </div>
                <StatusBadge status={a.status} />
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
