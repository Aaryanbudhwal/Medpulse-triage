import Link from "next/link";
import { redirect } from "next/navigation";
import { Stethoscope, MapPin } from "lucide-react";
import { auth } from "@/lib/auth";
import { listAppointmentsForPatient } from "@/lib/data/appointments";
import { cancelAppointment } from "@/lib/actions/doctors";
import { formatDateTime } from "@/lib/utils";
import StatusBadge from "@/components/status-badge";
import CancelButton from "@/components/cancel-button";

export default async function MyAppointmentsPage({
  searchParams,
}: {
  searchParams: Promise<{ booked?: string }>;
}) {
  const session = await auth();
  if (!session) redirect("/login");

  const { booked } = await searchParams;
  const appointments = await listAppointmentsForPatient(session.user.id);

  return (
    <div className="mx-auto max-w-3xl px-6 py-12">
      <h1 className="font-display text-3xl font-medium text-foreground">My appointments</h1>
      <p className="mt-2 text-muted-foreground">Your booked doctor visits.</p>

      {booked === "1" && (
        <p className="mt-6 rounded-xl bg-success-soft px-4 py-3 text-sm text-success">Appointment confirmed.</p>
      )}

      {appointments.length === 0 ? (
        <div className="mt-10 rounded-2xl border border-dashed border-card-border p-10 text-center text-muted-foreground">
          <p>No appointments yet.</p>
          <Link href="/doctors" className="mt-3 inline-block font-medium text-primary hover:underline">
            Find a doctor
          </Link>
        </div>
      ) : (
        <ul className="mt-8 space-y-4">
          {appointments.map((a) => (
            <li key={a.id} className="rounded-2xl border border-card-border bg-card p-5">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <Stethoscope className="h-4 w-4 text-primary" />
                    <p className="font-medium text-foreground">{a.doctorName}</p>
                    <span className="text-sm text-muted-foreground">· {a.specialty}</span>
                  </div>
                  <p className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
                    <MapPin className="h-3.5 w-3.5" /> {a.clinicName}, {a.city}
                  </p>
                  <p className="mt-1 text-sm font-medium text-foreground">{formatDateTime(a.startTime)}</p>
                  {a.reason && <p className="mt-1 text-sm text-muted-foreground">&ldquo;{a.reason}&rdquo;</p>}
                </div>

                <div className="flex flex-col items-end gap-2">
                  <StatusBadge status={a.status} />
                  {a.status === "CONFIRMED" && (
                    <CancelButton
                      action={cancelAppointment.bind(null, a.id)}
                      confirmText="Cancel this appointment?"
                    />
                  )}
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
