import Link from "next/link";
import { MapPin, Stethoscope, ArrowRight, SearchX, IndianRupee } from "lucide-react";
import { listDoctors, listSpecialties } from "@/lib/data/doctors";

export default async function DoctorsPage({
  searchParams,
}: {
  searchParams: Promise<{ city?: string; specialty?: string }>;
}) {
  const params = await searchParams;
  const city = params.city?.trim() || undefined;
  const specialty = params.specialty?.trim() || undefined;

  const [doctors, specialties] = await Promise.all([listDoctors({ city, specialty }), listSpecialties()]);

  return (
    <div className="mx-auto max-w-6xl px-6 py-12">
      <h1 className="font-display text-3xl font-medium text-foreground">Find a local doctor</h1>
      <p className="mt-2 text-muted-foreground">Search by specialty and city, then book an open slot.</p>

      <form className="mt-8 flex flex-wrap items-end gap-4 rounded-2xl border border-card-border bg-card p-5">
        <div className="min-w-[200px] flex-1">
          <label className="mb-1.5 block text-sm font-medium text-foreground" htmlFor="city">
            City
          </label>
          <input
            id="city"
            name="city"
            defaultValue={city}
            placeholder="e.g. Ghaziabad"
            className="w-full rounded-xl border border-card-border px-4 py-2.5 text-sm outline-none focus:border-primary"
          />
        </div>
        <div className="min-w-[200px] flex-1">
          <label className="mb-1.5 block text-sm font-medium text-foreground" htmlFor="specialty">
            Specialty
          </label>
          <input
            id="specialty"
            name="specialty"
            defaultValue={specialty}
            placeholder="e.g. Dermatologist"
            list="specialty-list"
            className="w-full rounded-xl border border-card-border px-4 py-2.5 text-sm outline-none focus:border-primary"
          />
          <datalist id="specialty-list">
            {specialties.map((s) => (
              <option key={s} value={s} />
            ))}
          </datalist>
        </div>
        <button
          type="submit"
          className="rounded-full bg-primary px-6 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90"
        >
          Search
        </button>
      </form>

      {doctors.length === 0 ? (
        <div className="mt-14 flex flex-col items-center gap-3 text-center text-muted-foreground">
          <SearchX className="h-8 w-8" />
          <p>No doctors match that search. Try a different city or specialty.</p>
        </div>
      ) : (
        <ul className="mt-8 grid gap-4 sm:grid-cols-2">
          {doctors.map((d) => (
            <li key={d.id}>
              <Link
                href={`/doctors/${d.id}`}
                className="flex h-full flex-col justify-between rounded-2xl border border-card-border bg-card p-6 hover:border-primary"
              >
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-display text-lg font-medium text-foreground">{d.name}</p>
                      <p className="mt-1 flex items-center gap-1.5 text-sm text-primary">
                        <Stethoscope className="h-3.5 w-3.5" /> {d.specialty}
                      </p>
                    </div>
                    <ArrowRight className="mt-1 h-4 w-4 shrink-0 text-muted-foreground" />
                  </div>
                  <p className="mt-3 flex items-center gap-1.5 text-sm text-muted-foreground">
                    <MapPin className="h-3.5 w-3.5" /> {d.clinicName}, {d.city}
                  </p>
                </div>
                {d.consultationFee != null && (
                  <p className="mt-4 flex items-center gap-1 text-sm font-medium text-foreground">
                    <IndianRupee className="h-3.5 w-3.5" /> {d.consultationFee} consultation
                  </p>
                )}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
