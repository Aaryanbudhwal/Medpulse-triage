import { Suspense } from "react";
import Link from "next/link";
import LoginForm from "@/components/login-form";

export default function LoginPage() {
  return (
    <div className="mx-auto max-w-md px-6 py-16">
      <h1 className="font-display text-3xl font-medium text-foreground">Log in</h1>
      <p className="mt-2 text-sm text-muted-foreground">Welcome back. Log in to reserve a bed or book an appointment.</p>

      <div className="mt-8 rounded-3xl border border-card-border bg-card p-7">
        <Suspense>
          <LoginForm />
        </Suspense>
      </div>

      <p className="mt-6 text-center text-sm text-muted-foreground">
        Don&apos;t have an account?{" "}
        <Link href="/register" className="font-medium text-primary hover:underline">
          Sign up
        </Link>
      </p>
    </div>
  );
}
