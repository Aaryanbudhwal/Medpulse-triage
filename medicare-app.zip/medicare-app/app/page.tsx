import Link from "next/link";
import { BedSingle, Stethoscope, ShieldPlus, CalendarCheck, Building2, ArrowUpRight } from "lucide-react";
import { db } from "@/lib/db";

async function getStats() {
  const bedTotals = await db
    .selectFrom("beds")
    .select(({ fn }) => [fn.sum<number>("availableCount").as("available"), fn.sum<number>("totalCount").as("total")])
    .executeTakeFirst();

  const hospitalCount = await db
    .selectFrom("hospitals")
    .select(({ fn }) => fn.count<number>("id").as("count"))
    .executeTakeFirst();

  const doctorCount = await db
    .selectFrom("doctors")
    .select(({ fn }) => fn.count<number>("id").as("count"))
    .executeTakeFirst();

  return {
    availableBeds: Number(bedTotals?.available ?? 0),
    hospitals: Number(hospitalCount?.count ?? 0),
    doctors: Number(doctorCount?.count ?? 0),
  };
}

export default async function HomePage() {
  const stats = await getStats();

  return (
    <div>
      <section className="mx-auto max-w-6xl px-6 pb-8 pt-16 sm:pt-24">
        <p className="font-display text-sm text-muted-foreground">MediCare</p>
        <h1 className="mt-3 max-w-2xl font-display text-4xl font-medium leading-tight text-foreground sm:text-5xl">
          Find a bed or a doctor without the waiting-room guesswork.
        </h1>
        <p className="mt-5 max-w-xl text-lg text-muted-foreground">
          One platform, two jobs: reserve an ICU or general bed at a nearby hospital in an emergency, or book a
          routine appointment with a local doctor. Pick a lane below.
        </p>

        <dl className="mt-10 flex flex-wrap gap-x-10 gap-y-4 border-t border-card-border pt-6">
          <div>
            <dt className="text-xs text-muted-foreground">Beds available now</dt>
            <dd className="font-display text-2xl font-medium text-foreground">{stats.availableBeds}</dd>
          </div>
          <div>
            <dt className="text-xs text-muted-foreground">Hospitals on the platform</dt>
            <dd className="font-display text-2xl font-medium text-foreground">{stats.hospitals}</dd>
          </div>
          <div>
            <dt className="text-xs text-muted-foreground">Doctors accepting bookings</dt>
            <dd className="font-display text-2xl font-medium text-foreground">{stats.doctors}</dd>
          </div>
        </dl>
      </section>

      <section className="mx-auto grid max-w-6xl gap-6 px-6 pb-24 pt-6 lg:grid-cols-5">
        <Link
          href="/beds"
          className="group relative flex flex-col justify-between overflow-hidden rounded-3xl bg-primary p-9 text-primary-foreground lg:col-span-3"
        >
          <div>
            <span className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-white/15">
              <BedSingle className="h-5 w-5" strokeWidth={2.25} />
            </span>
            <h2 className="mt-6 font-display text-3xl font-medium">Reserve a bed</h2>
            <p className="mt-3 max-w-sm text-primary-foreground/80">
              Check live ICU, general, ventilator, and oxygen bed availability at hospitals near you, and send a
              reservation request in minutes — flagged as emergency when it can&apos;t wait.
            </p>
          </div>
          <div className="mt-10 flex items-center gap-2 text-sm font-medium">
            <ShieldPlus className="h-4 w-4" />
            Browse hospitals and bed availability
            <ArrowUpRight className="h-4 w-4 transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </div>
        </Link>

        <Link
          href="/doctors"
          className="group relative flex flex-col justify-between overflow-hidden rounded-3xl border border-card-border bg-card p-9 lg:col-span-2"
        >
          <div>
            <span className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-primary-soft text-primary">
              <Stethoscope className="h-5 w-5" strokeWidth={2.25} />
            </span>
            <h2 className="mt-6 font-display text-3xl font-medium text-foreground">Book a doctor</h2>
            <p className="mt-3 text-muted-foreground">
              Search local doctors by specialty, see their open slots, and book a time that works for you.
            </p>
          </div>
          <div className="mt-10 flex items-center gap-2 text-sm font-medium text-primary">
            <CalendarCheck className="h-4 w-4" />
            Find a doctor and a time
            <ArrowUpRight className="h-4 w-4 transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </div>
        </Link>
      </section>

      <section className="border-t border-card-border bg-card">
        <div className="mx-auto max-w-6xl px-6 py-14">
          <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
            <Building2 className="h-4 w-4" />
            Running a hospital or a clinic?
          </div>
          <p className="mt-2 max-w-2xl text-foreground">
            Hospital admins can list bed inventory and manage incoming reservation requests. Doctors can open up
            appointment slots and manage their bookings.{" "}
            <Link href="/register" className="font-medium text-primary hover:underline">
              Create an account
            </Link>{" "}
            to get started.
          </p>
        </div>
      </section>
    </div>
  );
}
