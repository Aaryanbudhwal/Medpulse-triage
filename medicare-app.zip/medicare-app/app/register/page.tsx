import Link from "next/link";
import RegisterForm from "@/components/register-form";

export default function RegisterPage() {
  return (
    <div className="mx-auto max-w-xl px-6 py-16">
      <h1 className="font-display text-3xl font-medium text-foreground">Create an account</h1>
      <p className="mt-2 text-sm text-muted-foreground">Patients, hospital admins, and doctors all sign up here.</p>

      <div className="mt-8 rounded-3xl border border-card-border bg-card p-7">
        <RegisterForm />
      </div>

      <p className="mt-6 text-center text-sm text-muted-foreground">
        Already have an account?{" "}
        <Link href="/login" className="font-medium text-primary hover:underline">
          Log in
        </Link>
      </p>
    </div>
  );
}
