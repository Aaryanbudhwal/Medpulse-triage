"use client";

import { useState, useTransition } from "react";
import clsx from "clsx";

const variants = {
  primary: "border-primary text-primary hover:bg-primary-soft",
  danger: "border-danger text-danger hover:bg-danger-soft",
  outline: "border-card-border text-foreground hover:border-primary hover:text-primary",
};

export default function ActionButton({
  action,
  label,
  pendingLabel = "Working…",
  confirmText,
  variant = "outline",
}: {
  action: () => Promise<void>;
  label: string;
  pendingLabel?: string;
  confirmText?: string;
  variant?: keyof typeof variants;
}) {
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  return (
    <div className="flex flex-col items-end gap-1">
      <button
        type="button"
        disabled={isPending}
        onClick={() => {
          if (confirmText && !window.confirm(confirmText)) return;
          setError(null);
          startTransition(async () => {
            try {
              await action();
            } catch (err) {
              setError(err instanceof Error ? err.message : "Something went wrong.");
            }
          });
        }}
        className={clsx("rounded-full border px-4 py-1.5 text-xs font-medium disabled:opacity-50", variants[variant])}
      >
        {isPending ? pendingLabel : label}
      </button>
      {error && <p className="max-w-[16rem] text-right text-xs text-danger">{error}</p>}
    </div>
  );
}
