"use client";

import { useActionState } from "react";
import { addDoctorSlots, type ActionState } from "@/lib/actions/doctors";
import SubmitButton from "@/components/submit-button";

export default function AddSlotsForm() {
  const [state, formAction] = useActionState<ActionState, FormData>(addDoctorSlots, undefined);

  return (
    <form action={formAction} className="grid gap-3 sm:grid-cols-4">
      {state?.error && (
        <p className="rounded-lg bg-danger-soft px-3 py-2 text-sm text-danger sm:col-span-4">{state.error}</p>
      )}
      {state?.success && (
        <p className="rounded-lg bg-success-soft px-3 py-2 text-sm text-success sm:col-span-4">Slots added.</p>
      )}

      <label className="text-xs text-muted-foreground">
        Date
        <input
          type="date"
          name="date"
          required
          className="mt-1 w-full rounded-lg border border-card-border bg-card px-3 py-2 text-sm outline-none focus:border-primary"
        />
      </label>
      <label className="text-xs text-muted-foreground">
        Start time
        <input
          type="time"
          name="startTime"
          required
          className="mt-1 w-full rounded-lg border border-card-border bg-card px-3 py-2 text-sm outline-none focus:border-primary"
        />
      </label>
      <label className="text-xs text-muted-foreground">
        End time
        <input
          type="time"
          name="endTime"
          required
          className="mt-1 w-full rounded-lg border border-card-border bg-card px-3 py-2 text-sm outline-none focus:border-primary"
        />
      </label>
      <label className="text-xs text-muted-foreground">
        Slot length (min)
        <input
          type="number"
          name="duration"
          defaultValue={30}
          min={5}
          step={5}
          required
          className="mt-1 w-full rounded-lg border border-card-border bg-card px-3 py-2 text-sm outline-none focus:border-primary"
        />
      </label>

      <div className="sm:col-span-4">
        <SubmitButton pendingText="Adding…">Add slots</SubmitButton>
      </div>
    </form>
  );
}
