"use client";

import { useActionState, useState } from "react";
import { format, isSameDay } from "date-fns";
import { bookAppointment, type ActionState } from "@/lib/actions/doctors";
import SubmitButton from "@/components/submit-button";

type Slot = { id: string; startTime: Date; endTime: Date };

export default function BookAppointmentForm({ doctorId, slots }: { doctorId: string; slots: Slot[] }) {
  const [selectedSlotId, setSelectedSlotId] = useState<string | null>(null);
  const boundAction = bookAppointment.bind(null, doctorId);
  const [state, formAction] = useActionState<ActionState, FormData>(boundAction, undefined);

  if (slots.length === 0) {
    return <p className="text-sm text-muted-foreground">This doctor has no open slots right now. Check back soon.</p>;
  }

  const days: { label: string; slots: Slot[] }[] = [];
  for (const slot of slots) {
    const existing = days.find((d) => isSameDay(d.slots[0].startTime, slot.startTime));
    if (existing) existing.slots.push(slot);
    else days.push({ label: format(slot.startTime, "EEE, d MMM"), slots: [slot] });
  }

  return (
    <form action={formAction} className="space-y-6">
      <input type="hidden" name="slotId" value={selectedSlotId ?? ""} />

      <div className="space-y-4">
        {days.map((day) => (
          <div key={day.label}>
            <p className="mb-2 text-sm font-medium text-foreground">{day.label}</p>
            <div className="flex flex-wrap gap-2">
              {day.slots.map((slot) => (
                <button
                  key={slot.id}
                  type="button"
                  onClick={() => setSelectedSlotId(slot.id)}
                  className={`rounded-full border px-4 py-1.5 text-sm font-medium transition ${
                    selectedSlotId === slot.id
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-card-border text-foreground hover:border-primary"
                  }`}
                >
                  {format(slot.startTime, "h:mm a")}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      {selectedSlotId && (
        <div className="space-y-3 rounded-2xl bg-muted p-4">
          {state?.error && <p className="rounded-lg bg-danger-soft px-3 py-2 text-sm text-danger">{state.error}</p>}
          <div className="grid gap-3 sm:grid-cols-2">
            <input
              name="patientName"
              required
              placeholder="Patient's full name"
              className="rounded-xl border border-card-border bg-card px-3 py-2 text-sm outline-none focus:border-primary"
            />
            <input
              name="patientAge"
              type="number"
              min={0}
              placeholder="Age"
              className="rounded-xl border border-card-border bg-card px-3 py-2 text-sm outline-none focus:border-primary"
            />
            <input
              name="contactPhone"
              required
              placeholder="Contact phone"
              className="rounded-xl border border-card-border bg-card px-3 py-2 text-sm outline-none focus:border-primary sm:col-span-2"
            />
            <textarea
              name="reason"
              placeholder="Reason for visit (optional)"
              rows={2}
              className="rounded-xl border border-card-border bg-card px-3 py-2 text-sm outline-none focus:border-primary sm:col-span-2"
            />
          </div>
          <SubmitButton pendingText="Booking…">Confirm appointment</SubmitButton>
        </div>
      )}
    </form>
  );
}
