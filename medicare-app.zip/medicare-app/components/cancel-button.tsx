"use client";

import { useState, useTransition } from "react";

export default function CancelButton({
  action,
  confirmText = "Are you sure?",
  label = "Cancel",
}: {
  action: () => Promise<void>;
  confirmText?: string;
  label?: string;
}) {
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  return (
    <div className="flex flex-col items-end gap-1">
      <button
        type="button"
        disabled={isPending}
        onClick={() => {
          if (!window.confirm(confirmText)) return;
          setError(null);
          startTransition(async () => {
            try {
              await action();
            } catch (err) {
              setError(err instanceof Error ? err.message : "Something went wrong.");
            }
          });
        }}
        className="rounded-full border border-danger px-4 py-1.5 text-xs font-medium text-danger hover:bg-danger-soft disabled:opacity-50"
      >
        {isPending ? "Working…" : label}
      </button>
      {error && <p className="max-w-[16rem] text-right text-xs text-danger">{error}</p>}
    </div>
  );
}
