import Link from "next/link";
import { BedSingle, Stethoscope } from "lucide-react";
import { auth } from "@/lib/auth";
import { logout } from "@/lib/actions/auth";

const roleDashboard: Record<string, { href: string; label: string }> = {
  PATIENT: { href: "/dashboard", label: "My dashboard" },
  HOSPITAL_ADMIN: { href: "/beds/admin", label: "Hospital dashboard" },
  DOCTOR: { href: "/doctors/admin", label: "Doctor dashboard" },
};

export default async function Navbar() {
  const session = await auth();

  return (
    <header className="border-b border-card-border bg-card">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <Link href="/" className="flex items-center gap-2 font-display text-lg font-semibold text-foreground">
          <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
            <BedSingle className="h-4 w-4" strokeWidth={2.25} />
          </span>
          MediCare
        </Link>

        <nav className="hidden items-center gap-6 text-sm font-medium text-foreground/80 sm:flex">
          <Link href="/beds" className="flex items-center gap-1.5 hover:text-primary">
            <BedSingle className="h-4 w-4" /> Beds
          </Link>
          <Link href="/doctors" className="flex items-center gap-1.5 hover:text-primary">
            <Stethoscope className="h-4 w-4" /> Doctors
          </Link>
        </nav>

        <div className="flex items-center gap-4">
          {session ? (
            <>
              <Link
                href={roleDashboard[session.user.role]?.href ?? "/dashboard"}
                className="hidden text-sm font-medium text-foreground/80 hover:text-primary sm:inline"
              >
                {roleDashboard[session.user.role]?.label ?? "Dashboard"}
              </Link>
              <span className="hidden text-sm text-muted-foreground md:inline">{session.user.name}</span>
              <form action={logout}>
                <button
                  type="submit"
                  className="rounded-full border border-card-border px-4 py-1.5 text-sm font-medium text-foreground/80 hover:border-primary hover:text-primary"
                >
                  Log out
                </button>
              </form>
            </>
          ) : (
            <>
              <Link href="/login" className="text-sm font-medium text-foreground/80 hover:text-primary">
                Log in
              </Link>
              <Link
                href="/register"
                className="rounded-full bg-primary px-4 py-1.5 text-sm font-medium text-primary-foreground hover:opacity-90"
              >
                Sign up
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
