"use client";

import { useActionState, useState } from "react";
import { registerUser, type RegisterState } from "@/lib/actions/auth";
import SubmitButton from "@/components/submit-button";

const roles = [
  { value: "PATIENT", label: "Patient", blurb: "Reserve beds and book doctor appointments" },
  { value: "HOSPITAL_ADMIN", label: "Hospital admin", blurb: "List your hospital's beds and manage requests" },
  { value: "DOCTOR", label: "Doctor", blurb: "Open appointment slots and manage bookings" },
] as const;

export default function RegisterForm() {
  const [state, formAction] = useActionState<RegisterState, FormData>(registerUser, undefined);
  const [role, setRole] = useState<(typeof roles)[number]["value"]>("PATIENT");

  return (
    <form action={formAction} className="space-y-6">
      {state?.error && <p className="rounded-xl bg-danger-soft px-4 py-3 text-sm text-danger">{state.error}</p>}

      <div>
        <span className="mb-2 block text-sm font-medium text-foreground">I am a…</span>
        <div className="grid gap-2 sm:grid-cols-3">
          {roles.map((r) => (
            <label
              key={r.value}
              className={`cursor-pointer rounded-xl border p-3 text-sm transition ${
                role === r.value ? "border-primary bg-primary-soft" : "border-card-border hover:border-primary/50"
              }`}
            >
              <input
                type="radio"
                name="role"
                value={r.value}
                checked={role === r.value}
                onChange={() => setRole(r.value)}
                className="sr-only"
              />
              <span className="block font-medium text-foreground">{r.label}</span>
              <span className="mt-0.5 block text-xs text-muted-foreground">{r.blurb}</span>
            </label>
          ))}
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Full name" name="name" required />
        <Field label="Phone" name="phone" type="tel" />
        <Field label="Email" name="email" type="email" required className="sm:col-span-2" />
        <Field
          label="Password"
          name="password"
          type="password"
          required
          minLength={8}
          hint="At least 8 characters"
          className="sm:col-span-2"
        />
      </div>

      {role === "HOSPITAL_ADMIN" && (
        <div className="space-y-4 rounded-2xl bg-muted p-4">
          <p className="text-sm font-medium text-foreground">Hospital details</p>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Hospital name" name="hospitalName" required />
            <Field label="Hospital phone" name="hospitalPhone" type="tel" />
            <Field label="Address" name="address" required className="sm:col-span-2" />
            <Field label="City" name="city" required />
          </div>
        </div>
      )}

      {role === "DOCTOR" && (
        <div className="space-y-4 rounded-2xl bg-muted p-4">
          <p className="text-sm font-medium text-foreground">Practice details</p>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Specialty" name="specialty" placeholder="e.g. Cardiologist" required />
            <Field label="City" name="city" required />
            <Field label="Clinic name" name="clinicName" required />
            <Field label="Consultation fee (₹)" name="consultationFee" type="number" min={0} />
            <Field label="Clinic address" name="address" required className="sm:col-span-2" />
          </div>
        </div>
      )}

      <SubmitButton className="w-full" pendingText="Creating account…">
        Create account
      </SubmitButton>
    </form>
  );
}

function Field({
  label,
  name,
  type = "text",
  required,
  minLength,
  min,
  placeholder,
  hint,
  className,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
  minLength?: number;
  min?: number;
  placeholder?: string;
  hint?: string;
  className?: string;
}) {
  return (
    <div className={className}>
      <label htmlFor={name} className="mb-1.5 block text-sm font-medium text-foreground">
        {label}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        required={required}
        minLength={minLength}
        min={min}
        placeholder={placeholder}
        className="w-full rounded-xl border border-card-border bg-card px-4 py-2.5 text-sm outline-none focus:border-primary"
      />
      {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}
