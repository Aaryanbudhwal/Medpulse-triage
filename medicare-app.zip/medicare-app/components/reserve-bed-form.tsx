"use client";

import { useActionState, useState } from "react";
import { createReservation, type ReservationState } from "@/lib/actions/beds";
import SubmitButton from "@/components/submit-button";

export default function ReserveBedForm({
  bedId,
  hospitalId,
  disabled,
}: {
  bedId: string;
  hospitalId: string;
  disabled?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const boundAction = createReservation.bind(null, bedId, hospitalId);
  const [state, formAction] = useActionState<ReservationState, FormData>(boundAction, undefined);

  if (!open) {
    return (
      <button
        type="button"
        disabled={disabled}
        onClick={() => setOpen(true)}
        className="rounded-full bg-primary px-5 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
      >
        {disabled ? "Unavailable" : "Reserve this bed"}
      </button>
    );
  }

  return (
    <form action={formAction} className="mt-4 space-y-3 rounded-2xl bg-muted p-4">
      {state?.error && <p className="rounded-lg bg-danger-soft px-3 py-2 text-sm text-danger">{state.error}</p>}

      <div className="grid gap-3 sm:grid-cols-2">
        <input
          name="patientName"
          required
          placeholder="Patient's full name"
          className="rounded-xl border border-card-border bg-card px-3 py-2 text-sm outline-none focus:border-primary"
        />
        <input
          name="patientAge"
          type="number"
          min={0}
          placeholder="Age"
          className="rounded-xl border border-card-border bg-card px-3 py-2 text-sm outline-none focus:border-primary"
        />
        <input
          name="contactPhone"
          required
          placeholder="Contact phone"
          className="rounded-xl border border-card-border bg-card px-3 py-2 text-sm outline-none focus:border-primary sm:col-span-2"
        />
        <textarea
          name="notes"
          placeholder="Notes for the hospital (optional)"
          rows={2}
          className="rounded-xl border border-card-border bg-card px-3 py-2 text-sm outline-none focus:border-primary sm:col-span-2"
        />
      </div>

      <label className="flex items-center gap-2 text-sm text-foreground">
        <input type="checkbox" name="isEmergency" className="h-4 w-4 rounded border-card-border accent-accent" />
        This is an emergency
      </label>

      <div className="flex gap-2">
        <SubmitButton pendingText="Sending request…">Send reservation request</SubmitButton>
        <button
          type="button"
          onClick={() => setOpen(false)}
          className="rounded-full border border-card-border px-5 py-2.5 text-sm font-medium text-foreground hover:border-primary"
        >
          Cancel
        </button>
      </div>
    </form>
  );
}
