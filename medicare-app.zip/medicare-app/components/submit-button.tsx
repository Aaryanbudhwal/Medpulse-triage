"use client";

import { useFormStatus } from "react-dom";
import clsx from "clsx";

const variants = {
  primary: "bg-primary text-primary-foreground hover:opacity-90",
  accent: "bg-accent text-accent-foreground hover:opacity-90",
  outline: "border border-card-border text-foreground hover:border-primary hover:text-primary",
  danger: "border border-danger text-danger hover:bg-danger-soft",
};

export default function SubmitButton({
  children,
  pendingText = "Please wait…",
  className,
  variant = "primary",
}: {
  children: React.ReactNode;
  pendingText?: string;
  className?: string;
  variant?: keyof typeof variants;
}) {
  const { pending } = useFormStatus();

  return (
    <button
      type="submit"
      disabled={pending}
      className={clsx(
        "inline-flex items-center justify-center rounded-full px-5 py-2.5 text-sm font-medium transition disabled:opacity-60",
        variants[variant],
        className
      )}
    >
      {pending ? pendingText : children}
    </button>
  );
}
