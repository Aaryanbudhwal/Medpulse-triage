-- MediCare platform schema
-- Run once against a fresh Postgres database:
--   psql "$DATABASE_URL" -f db/schema.sql

create extension if not exists pgcrypto;

-- ---------- Auth / Users ----------

create type role as enum ('PATIENT', 'HOSPITAL_ADMIN', 'DOCTOR');

create table users (
  id text primary key default gen_random_uuid()::text,
  name text not null,
  email text not null unique,
  password_hash text not null,
  phone text,
  role role not null default 'PATIENT',
  created_at timestamptz not null default now()
);

-- ---------- Module 1: Bed reservation ----------

create type bed_type as enum ('ICU', 'GENERAL', 'VENTILATOR', 'OXYGEN');
create type reservation_status as enum ('PENDING', 'CONFIRMED', 'REJECTED', 'CANCELLED', 'COMPLETED');

create table hospitals (
  id text primary key default gen_random_uuid()::text,
  name text not null,
  address text not null,
  city text not null,
  phone text,
  admin_id text not null unique references users(id) on delete restrict,
  created_at timestamptz not null default now()
);

create table beds (
  id text primary key default gen_random_uuid()::text,
  hospital_id text not null references hospitals(id) on delete cascade,
  type bed_type not null,
  total_count integer not null check (total_count >= 0),
  available_count integer not null check (available_count >= 0),
  unique (hospital_id, type)
);

create table bed_reservations (
  id text primary key default gen_random_uuid()::text,
  bed_id text not null references beds(id),
  hospital_id text not null references hospitals(id),
  patient_id text not null references users(id),
  patient_name text not null,
  patient_age integer,
  contact_phone text not null,
  is_emergency boolean not null default false,
  notes text,
  status reservation_status not null default 'PENDING',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_bed_reservations_patient on bed_reservations(patient_id);
create index idx_bed_reservations_hospital on bed_reservations(hospital_id, status);

-- ---------- Module 2: Doctor appointments ----------

create type appointment_status as enum ('CONFIRMED', 'CANCELLED', 'COMPLETED');

create table doctors (
  id text primary key default gen_random_uuid()::text,
  user_id text not null unique references users(id) on delete restrict,
  name text not null,
  specialty text not null,
  city text not null,
  clinic_name text not null,
  address text not null,
  consultation_fee integer,
  bio text,
  created_at timestamptz not null default now()
);

create table doctor_slots (
  id text primary key default gen_random_uuid()::text,
  doctor_id text not null references doctors(id) on delete cascade,
  start_time timestamptz not null,
  end_time timestamptz not null,
  is_booked boolean not null default false
);

create index idx_doctor_slots_doctor_time on doctor_slots(doctor_id, start_time);

create table appointments (
  id text primary key default gen_random_uuid()::text,
  slot_id text not null references doctor_slots(id),
  doctor_id text not null references doctors(id),
  patient_id text not null references users(id),
  patient_name text not null,
  patient_age integer,
  contact_phone text not null,
  reason text,
  status appointment_status not null default 'CONFIRMED',
  created_at timestamptz not null default now()
);

create index idx_appointments_patient on appointments(patient_id);
create index idx_appointments_doctor on appointments(doctor_id);

-- keep bed_reservations.updated_at fresh
create or replace function set_updated_at() returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger trg_bed_reservations_updated_at
before update on bed_reservations
for each row execute function set_updated_at();
