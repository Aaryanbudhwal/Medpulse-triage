"use server";

import bcrypt from "bcryptjs";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { signOut } from "@/lib/auth";

export async function logout() {
  await signOut({ redirectTo: "/" });
}

export type RegisterState = { error?: string } | undefined;

const BED_TYPES = ["ICU", "GENERAL", "VENTILATOR", "OXYGEN"] as const;

export async function registerUser(_prevState: RegisterState, formData: FormData): Promise<RegisterState> {
  const name = String(formData.get("name") || "").trim();
  const email = String(formData.get("email") || "").trim().toLowerCase();
  const password = String(formData.get("password") || "");
  const phone = String(formData.get("phone") || "").trim() || null;
  const role = String(formData.get("role") || "PATIENT") as "PATIENT" | "HOSPITAL_ADMIN" | "DOCTOR";

  if (!name || !email || password.length < 8) {
    return { error: "Please fill in all required fields. Password must be at least 8 characters." };
  }

  const existing = await db.selectFrom("users").select("id").where("email", "=", email).executeTakeFirst();
  if (existing) {
    return { error: "An account with this email already exists." };
  }

  const passwordHash = await bcrypt.hash(password, 10);

  try {
    await db.transaction().execute(async (trx) => {
      const user = await trx
        .insertInto("users")
        .values({ name, email, passwordHash, phone, role })
        .returning(["id"])
        .executeTakeFirstOrThrow();

      if (role === "HOSPITAL_ADMIN") {
        const hospitalName = String(formData.get("hospitalName") || "").trim();
        const address = String(formData.get("address") || "").trim();
        const city = String(formData.get("city") || "").trim();
        const hospitalPhone = String(formData.get("hospitalPhone") || "").trim() || null;
        if (!hospitalName || !address || !city) {
          throw new Error("Hospital name, address, and city are required.");
        }

        const hospital = await trx
          .insertInto("hospitals")
          .values({ name: hospitalName, address, city, phone: hospitalPhone, adminId: user.id })
          .returning(["id"])
          .executeTakeFirstOrThrow();

        await trx
          .insertInto("beds")
          .values(
            BED_TYPES.map((type) => ({
              hospitalId: hospital.id,
              type,
              totalCount: 0,
              availableCount: 0,
            }))
          )
          .execute();
      }

      if (role === "DOCTOR") {
        const specialty = String(formData.get("specialty") || "").trim();
        const city = String(formData.get("city") || "").trim();
        const clinicName = String(formData.get("clinicName") || "").trim();
        const address = String(formData.get("address") || "").trim();
        const feeRaw = String(formData.get("consultationFee") || "").trim();
        const consultationFee = feeRaw ? Number(feeRaw) : null;
        if (!specialty || !city || !clinicName || !address) {
          throw new Error("Specialty, city, clinic name, and address are required.");
        }

        await trx
          .insertInto("doctors")
          .values({ userId: user.id, name, specialty, city, clinicName, address, consultationFee })
          .execute();
      }
    });
  } catch (err) {
    return { error: err instanceof Error ? err.message : "Something went wrong. Please try again." };
  }

  redirect("/login?registered=1");
}
