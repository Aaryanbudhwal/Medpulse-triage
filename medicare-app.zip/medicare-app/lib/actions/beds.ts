"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import type { BedType } from "@/lib/db";

export type ReservationState = { error?: string } | undefined;

export async function createReservation(
  bedId: string,
  hospitalId: string,
  _prevState: ReservationState,
  formData: FormData
): Promise<ReservationState> {
  const session = await auth();
  if (!session) redirect("/login");
  if (session.user.role !== "PATIENT") {
    return { error: "Only patient accounts can reserve beds." };
  }

  const patientName = String(formData.get("patientName") || "").trim();
  const patientAgeRaw = String(formData.get("patientAge") || "").trim();
  const contactPhone = String(formData.get("contactPhone") || "").trim();
  const isEmergency = formData.get("isEmergency") === "on";
  const notes = String(formData.get("notes") || "").trim() || null;
  const patientAge = patientAgeRaw ? Number(patientAgeRaw) : null;

  if (!patientName || !contactPhone) {
    return { error: "Patient name and contact phone are required." };
  }

  try {
    await db.transaction().execute(async (trx) => {
      const updated = await trx
        .updateTable("beds")
        .set((eb) => ({ availableCount: eb("availableCount", "-", 1) }))
        .where("id", "=", bedId)
        .where("availableCount", ">", 0)
        .returning(["id"])
        .executeTakeFirst();

      if (!updated) {
        throw new Error("Sorry, no beds of this type are available right now.");
      }

      await trx
        .insertInto("bedReservations")
        .values({
          bedId,
          hospitalId,
          patientId: session.user.id,
          patientName,
          patientAge,
          contactPhone,
          isEmergency,
          notes,
          status: "PENDING",
        })
        .execute();
    });
  } catch (err) {
    return { error: err instanceof Error ? err.message : "Something went wrong. Please try again." };
  }

  revalidatePath(`/beds/${hospitalId}`);
  revalidatePath("/beds");
  redirect("/beds/reservations?requested=1");
}

export async function cancelReservation(reservationId: string) {
  const session = await auth();
  if (!session) throw new Error("Not authorized.");

  const reservation = await db
    .selectFrom("bedReservations")
    .selectAll()
    .where("id", "=", reservationId)
    .executeTakeFirst();

  if (!reservation || reservation.patientId !== session.user.id) {
    throw new Error("Not authorized.");
  }
  if (reservation.status !== "PENDING" && reservation.status !== "CONFIRMED") {
    throw new Error("This reservation can no longer be cancelled.");
  }

  await db.transaction().execute(async (trx) => {
    await trx
      .updateTable("beds")
      .set((eb) => ({ availableCount: eb("availableCount", "+", 1) }))
      .where("id", "=", reservation.bedId)
      .execute();
    await trx.updateTable("bedReservations").set({ status: "CANCELLED" }).where("id", "=", reservationId).execute();
  });

  revalidatePath("/beds/reservations");
}

export async function updateReservationStatus(
  reservationId: string,
  newStatus: "CONFIRMED" | "REJECTED" | "COMPLETED"
) {
  const session = await auth();
  if (!session || session.user.role !== "HOSPITAL_ADMIN") throw new Error("Not authorized.");

  const reservation = await db
    .selectFrom("bedReservations")
    .innerJoin("hospitals", "hospitals.id", "bedReservations.hospitalId")
    .select(["bedReservations.id", "bedReservations.bedId", "bedReservations.status", "hospitals.adminId"])
    .where("bedReservations.id", "=", reservationId)
    .executeTakeFirst();

  if (!reservation || reservation.adminId !== session.user.id) throw new Error("Not authorized.");
  if (reservation.status !== "PENDING" && newStatus !== "COMPLETED") {
    throw new Error("This request has already been handled.");
  }

  await db.transaction().execute(async (trx) => {
    if (newStatus === "REJECTED" || newStatus === "COMPLETED") {
      await trx
        .updateTable("beds")
        .set((eb) => ({ availableCount: eb("availableCount", "+", 1) }))
        .where("id", "=", reservation.bedId)
        .execute();
    }
    await trx.updateTable("bedReservations").set({ status: newStatus }).where("id", "=", reservationId).execute();
  });

  revalidatePath("/beds/admin");
}

const BED_TYPES: BedType[] = ["ICU", "GENERAL", "VENTILATOR", "OXYGEN"];

export async function updateBedCounts(hospitalId: string, formData: FormData) {
  const session = await auth();
  if (!session || session.user.role !== "HOSPITAL_ADMIN") throw new Error("Not authorized.");

  const hospital = await db
    .selectFrom("hospitals")
    .select(["id", "adminId"])
    .where("id", "=", hospitalId)
    .executeTakeFirst();
  if (!hospital || hospital.adminId !== session.user.id) throw new Error("Not authorized.");

  for (const type of BED_TYPES) {
    const total = Number(formData.get(`total_${type}`) ?? 0);
    const available = Number(formData.get(`available_${type}`) ?? 0);
    if (!Number.isFinite(total) || !Number.isFinite(available)) continue;
    if (total < 0 || available < 0 || available > total) continue;

    await db
      .updateTable("beds")
      .set({ totalCount: total, availableCount: available })
      .where("hospitalId", "=", hospitalId)
      .where("type", "=", type)
      .execute();
  }

  revalidatePath("/beds/admin");
  revalidatePath("/beds");
}
