"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";

export type ActionState = { error?: string; success?: boolean } | undefined;

export async function addDoctorSlots(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const session = await auth();
  if (!session || session.user.role !== "DOCTOR") return { error: "Not authorized." };

  const doctor = await db.selectFrom("doctors").select(["id"]).where("userId", "=", session.user.id).executeTakeFirst();
  if (!doctor) return { error: "Doctor profile not found." };

  const date = String(formData.get("date") || "");
  const startTime = String(formData.get("startTime") || "");
  const endTime = String(formData.get("endTime") || "");
  const duration = Number(formData.get("duration") || 30);

  if (!date || !startTime || !endTime || !duration || duration < 5) {
    return { error: "Please fill in date, start/end time, and a valid slot length (minutes)." };
  }

  const start = new Date(`${date}T${startTime}:00`);
  const end = new Date(`${date}T${endTime}:00`);
  if (!(start.getTime() < end.getTime())) {
    return { error: "End time must be after start time." };
  }
  if (start.getTime() < Date.now() - 60 * 60 * 1000) {
    return { error: "Pick a date/time in the future." };
  }

  const slots: { doctorId: string; startTime: Date; endTime: Date }[] = [];
  let cursor = start;
  while (cursor.getTime() < end.getTime()) {
    const slotEnd = new Date(cursor.getTime() + duration * 60000);
    if (slotEnd.getTime() > end.getTime()) break;
    slots.push({ doctorId: doctor.id, startTime: cursor, endTime: slotEnd });
    cursor = slotEnd;
  }

  if (slots.length === 0) {
    return { error: "No slots fit in that time range with the chosen slot length." };
  }

  await db.insertInto("doctorSlots").values(slots).execute();
  revalidatePath("/doctors/admin");
  return { success: true };
}

export async function removeDoctorSlot(slotId: string) {
  const session = await auth();
  if (!session || session.user.role !== "DOCTOR") throw new Error("Not authorized.");

  const doctor = await db.selectFrom("doctors").select(["id"]).where("userId", "=", session.user.id).executeTakeFirst();
  if (!doctor) throw new Error("Not authorized.");

  const slot = await db.selectFrom("doctorSlots").selectAll().where("id", "=", slotId).executeTakeFirst();
  if (!slot || slot.doctorId !== doctor.id) throw new Error("Not authorized.");
  if (slot.isBooked) throw new Error("This slot is already booked and can't be removed.");

  await db.deleteFrom("doctorSlots").where("id", "=", slotId).execute();
  revalidatePath("/doctors/admin");
}

export async function bookAppointment(
  doctorId: string,
  _prevState: ActionState,
  formData: FormData
): Promise<ActionState> {
  const session = await auth();
  if (!session) redirect("/login");
  if (session.user.role !== "PATIENT") {
    return { error: "Only patient accounts can book appointments." };
  }

  const slotId = String(formData.get("slotId") || "");
  const patientName = String(formData.get("patientName") || "").trim();
  const patientAgeRaw = String(formData.get("patientAge") || "").trim();
  const contactPhone = String(formData.get("contactPhone") || "").trim();
  const reason = String(formData.get("reason") || "").trim() || null;
  const patientAge = patientAgeRaw ? Number(patientAgeRaw) : null;

  if (!slotId) {
    return { error: "Please pick a time slot." };
  }
  if (!patientName || !contactPhone) {
    return { error: "Patient name and contact phone are required." };
  }

  try {
    await db.transaction().execute(async (trx) => {
      const updated = await trx
        .updateTable("doctorSlots")
        .set({ isBooked: true })
        .where("id", "=", slotId)
        .where("isBooked", "=", false)
        .returning(["id"])
        .executeTakeFirst();

      if (!updated) {
        throw new Error("Sorry, this slot was just booked by someone else. Please pick another.");
      }

      await trx
        .insertInto("appointments")
        .values({ slotId, doctorId, patientId: session.user.id, patientName, patientAge, contactPhone, reason, status: "CONFIRMED" })
        .execute();
    });
  } catch (err) {
    return { error: err instanceof Error ? err.message : "Something went wrong. Please try again." };
  }

  revalidatePath(`/doctors/${doctorId}`);
  redirect("/doctors/appointments?booked=1");
}

export async function cancelAppointment(appointmentId: string) {
  const session = await auth();
  if (!session) throw new Error("Not authorized.");

  const appt = await db.selectFrom("appointments").selectAll().where("id", "=", appointmentId).executeTakeFirst();
  if (!appt || appt.patientId !== session.user.id) throw new Error("Not authorized.");
  if (appt.status !== "CONFIRMED") throw new Error("This appointment can no longer be cancelled.");

  await db.transaction().execute(async (trx) => {
    await trx.updateTable("doctorSlots").set({ isBooked: false }).where("id", "=", appt.slotId).execute();
    await trx.updateTable("appointments").set({ status: "CANCELLED" }).where("id", "=", appointmentId).execute();
  });

  revalidatePath("/doctors/appointments");
}

export async function markAppointmentCompleted(appointmentId: string) {
  const session = await auth();
  if (!session || session.user.role !== "DOCTOR") throw new Error("Not authorized.");

  const doctor = await db.selectFrom("doctors").select(["id"]).where("userId", "=", session.user.id).executeTakeFirst();
  if (!doctor) throw new Error("Not authorized.");

  const appt = await db.selectFrom("appointments").selectAll().where("id", "=", appointmentId).executeTakeFirst();
  if (!appt || appt.doctorId !== doctor.id) throw new Error("Not authorized.");

  await db.updateTable("appointments").set({ status: "COMPLETED" }).where("id", "=", appointmentId).execute();
  revalidatePath("/doctors/admin");
}
