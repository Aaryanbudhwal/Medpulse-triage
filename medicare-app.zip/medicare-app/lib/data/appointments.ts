import { db } from "@/lib/db";

export async function listAppointmentsForPatient(patientId: string) {
  return db
    .selectFrom("appointments")
    .innerJoin("doctors", "doctors.id", "appointments.doctorId")
    .innerJoin("doctorSlots", "doctorSlots.id", "appointments.slotId")
    .select([
      "appointments.id",
      "appointments.status",
      "appointments.reason",
      "appointments.createdAt",
      "doctorSlots.startTime",
      "doctors.name as doctorName",
      "doctors.specialty",
      "doctors.clinicName",
      "doctors.city",
    ])
    .where("appointments.patientId", "=", patientId)
    .orderBy("doctorSlots.startTime", "desc")
    .execute();
}

export async function listAppointmentsForDoctor(doctorId: string) {
  return db
    .selectFrom("appointments")
    .innerJoin("doctorSlots", "doctorSlots.id", "appointments.slotId")
    .select([
      "appointments.id",
      "appointments.status",
      "appointments.reason",
      "appointments.patientName",
      "appointments.patientAge",
      "appointments.contactPhone",
      "doctorSlots.startTime",
      "doctorSlots.endTime",
    ])
    .where("appointments.doctorId", "=", doctorId)
    .orderBy("doctorSlots.startTime", "desc")
    .execute();
}
