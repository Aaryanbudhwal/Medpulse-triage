import { db } from "@/lib/db";

export async function listDoctors(filters: { city?: string; specialty?: string } = {}) {
  let query = db.selectFrom("doctors").selectAll().orderBy("name");
  if (filters.city) query = query.where("city", "ilike", `%${filters.city}%`);
  if (filters.specialty) query = query.where("specialty", "ilike", `%${filters.specialty}%`);
  return query.execute();
}

export async function listSpecialties() {
  const rows = await db.selectFrom("doctors").select("specialty").distinct().orderBy("specialty").execute();
  return rows.map((r) => r.specialty);
}

export async function getDoctorById(id: string) {
  return db.selectFrom("doctors").selectAll().where("id", "=", id).executeTakeFirst();
}

export async function getDoctorByUserId(userId: string) {
  return db.selectFrom("doctors").selectAll().where("userId", "=", userId).executeTakeFirst();
}

export async function listBookableSlots(doctorId: string) {
  return db
    .selectFrom("doctorSlots")
    .selectAll()
    .where("doctorId", "=", doctorId)
    .where("startTime", ">", new Date())
    .where("isBooked", "=", false)
    .orderBy("startTime")
    .execute();
}

export async function listUpcomingSlotsForAdmin(doctorId: string) {
  return db
    .selectFrom("doctorSlots")
    .selectAll()
    .where("doctorId", "=", doctorId)
    .where("startTime", ">", new Date())
    .orderBy("startTime")
    .execute();
}
