import { db } from "@/lib/db";
import type { BedType } from "@/lib/db";

export async function listHospitals(filters: { city?: string; bedType?: BedType } = {}) {
  let query = db.selectFrom("hospitals").selectAll("hospitals").orderBy("hospitals.name");
  if (filters.city) {
    query = query.where("hospitals.city", "ilike", `%${filters.city}%`);
  }
  const hospitals = await query.execute();
  const beds = await db.selectFrom("beds").selectAll().execute();

  const bedsByHospital = new Map<string, typeof beds>();
  for (const bed of beds) {
    const list = bedsByHospital.get(bed.hospitalId) ?? [];
    list.push(bed);
    bedsByHospital.set(bed.hospitalId, list);
  }

  let result = hospitals.map((h) => ({ ...h, beds: bedsByHospital.get(h.id) ?? [] }));

  if (filters.bedType) {
    result = result.filter((h) => h.beds.some((b) => b.type === filters.bedType));
  }

  return result;
}

export async function getHospitalById(id: string) {
  const hospital = await db.selectFrom("hospitals").selectAll().where("id", "=", id).executeTakeFirst();
  if (!hospital) return null;
  const beds = await db.selectFrom("beds").selectAll().where("hospitalId", "=", id).orderBy("type").execute();
  return { ...hospital, beds };
}

export async function getHospitalByAdminId(adminId: string) {
  const hospital = await db.selectFrom("hospitals").selectAll().where("adminId", "=", adminId).executeTakeFirst();
  if (!hospital) return null;
  const beds = await db.selectFrom("beds").selectAll().where("hospitalId", "=", hospital.id).orderBy("type").execute();
  return { ...hospital, beds };
}
