import { db } from "@/lib/db";

export async function listReservationsForPatient(patientId: string) {
  return db
    .selectFrom("bedReservations")
    .innerJoin("hospitals", "hospitals.id", "bedReservations.hospitalId")
    .innerJoin("beds", "beds.id", "bedReservations.bedId")
    .select([
      "bedReservations.id",
      "bedReservations.status",
      "bedReservations.isEmergency",
      "bedReservations.createdAt",
      "beds.type as bedType",
      "hospitals.name as hospitalName",
      "hospitals.city as hospitalCity",
      "hospitals.phone as hospitalPhone",
    ])
    .where("bedReservations.patientId", "=", patientId)
    .orderBy("bedReservations.createdAt", "desc")
    .execute();
}

export async function listReservationsForHospital(hospitalId: string) {
  return db
    .selectFrom("bedReservations")
    .innerJoin("beds", "beds.id", "bedReservations.bedId")
    .select([
      "bedReservations.id",
      "bedReservations.status",
      "bedReservations.isEmergency",
      "bedReservations.notes",
      "bedReservations.patientName",
      "bedReservations.patientAge",
      "bedReservations.contactPhone",
      "bedReservations.createdAt",
      "beds.type as bedType",
    ])
    .where("bedReservations.hospitalId", "=", hospitalId)
    .orderBy("bedReservations.createdAt", "desc")
    .execute();
}
