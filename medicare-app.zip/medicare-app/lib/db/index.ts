import { CamelCasePlugin, Kysely, PostgresDialect } from "kysely";
import { Pool } from "pg";
import type { DB } from "./types.generated";

declare global {
  // eslint-disable-next-line no-var
  var __db__: Kysely<DB> | undefined;
}

function createDb() {
  return new Kysely<DB>({
    dialect: new PostgresDialect({
      pool: new Pool({
        connectionString: process.env.DATABASE_URL,
        max: 10,
      }),
    }),
    // Table/column names are snake_case in Postgres; this plugin lets us use
    // camelCase everywhere in TypeScript and translates automatically.
    plugins: [new CamelCasePlugin()],
  });
}

// Reuse the same connection pool across hot reloads in dev.
export const db = globalThis.__db__ ?? createDb();
if (process.env.NODE_ENV !== "production") globalThis.__db__ = db;

export type { DB } from "./types.generated";
export * from "./types.generated";
