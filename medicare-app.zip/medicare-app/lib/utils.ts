import { format } from "date-fns";

export const bedTypeLabels: Record<string, string> = {
  ICU: "ICU",
  GENERAL: "General",
  VENTILATOR: "Ventilator",
  OXYGEN: "Oxygen",
};

export const bedTypeDescriptions: Record<string, string> = {
  ICU: "Intensive care, continuous monitoring",
  GENERAL: "Standard inpatient ward bed",
  VENTILATOR: "ICU bed with ventilator support",
  OXYGEN: "Bed with oxygen supply",
};

export function formatDateTime(date: Date | string) {
  return format(new Date(date), "EEE, d MMM yyyy · h:mm a");
}

export function formatDate(date: Date | string) {
  return format(new Date(date), "EEE, d MMM yyyy");
}

export function formatTime(date: Date | string) {
  return format(new Date(date), "h:mm a");
}
