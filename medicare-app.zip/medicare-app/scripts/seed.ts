import "dotenv/config";
import bcrypt from "bcryptjs";
import { addDays, setHours, setMinutes, setSeconds, setMilliseconds } from "date-fns";
import { db } from "../lib/db";

const DEMO_PASSWORD = "password123";

async function main() {
  console.log("Clearing existing data…");
  await db.deleteFrom("appointments").execute();
  await db.deleteFrom("doctorSlots").execute();
  await db.deleteFrom("bedReservations").execute();
  await db.deleteFrom("beds").execute();
  await db.deleteFrom("doctors").execute();
  await db.deleteFrom("hospitals").execute();
  await db.deleteFrom("users").execute();

  const passwordHash = await bcrypt.hash(DEMO_PASSWORD, 10);

  console.log("Creating users…");
  const patient = await db
    .insertInto("users")
    .values({ name: "Aisha Verma", email: "patient@example.com", passwordHash, phone: "9876500001", role: "PATIENT" })
    .returning(["id"])
    .executeTakeFirstOrThrow();

  const hospitalAdmin1 = await db
    .insertInto("users")
    .values({ name: "Ramesh Gupta", email: "hospital1@example.com", passwordHash, phone: "9876500002", role: "HOSPITAL_ADMIN" })
    .returning(["id"])
    .executeTakeFirstOrThrow();

  const hospitalAdmin2 = await db
    .insertInto("users")
    .values({ name: "Neha Singh", email: "hospital2@example.com", passwordHash, phone: "9876500003", role: "HOSPITAL_ADMIN" })
    .returning(["id"])
    .executeTakeFirstOrThrow();

  const doctorUser1 = await db
    .insertInto("users")
    .values({ name: "Dr. Kavita Rao", email: "doctor1@example.com", passwordHash, phone: "9876500004", role: "DOCTOR" })
    .returning(["id"])
    .executeTakeFirstOrThrow();

  const doctorUser2 = await db
    .insertInto("users")
    .values({ name: "Dr. Arjun Mehta", email: "doctor2@example.com", passwordHash, phone: "9876500005", role: "DOCTOR" })
    .returning(["id"])
    .executeTakeFirstOrThrow();

  const doctorUser3 = await db
    .insertInto("users")
    .values({ name: "Dr. Sana Iqbal", email: "doctor3@example.com", passwordHash, phone: "9876500006", role: "DOCTOR" })
    .returning(["id"])
    .executeTakeFirstOrThrow();

  console.log("Creating hospitals + beds…");
  const hospital1 = await db
    .insertInto("hospitals")
    .values({
      name: "Sunrise Multispecialty Hospital",
      address: "12 GT Road",
      city: "Ghaziabad",
      phone: "0120-4567890",
      adminId: hospitalAdmin1.id,
    })
    .returning(["id"])
    .executeTakeFirstOrThrow();

  const hospital2 = await db
    .insertInto("hospitals")
    .values({
      name: "Apex Care Hospital",
      address: "45 Sector 62",
      city: "Noida",
      phone: "0120-9988776",
      adminId: hospitalAdmin2.id,
    })
    .returning(["id"])
    .executeTakeFirstOrThrow();

  const bedsH1 = await db
    .insertInto("beds")
    .values([
      { hospitalId: hospital1.id, type: "ICU", totalCount: 10, availableCount: 3 },
      { hospitalId: hospital1.id, type: "GENERAL", totalCount: 60, availableCount: 22 },
      { hospitalId: hospital1.id, type: "VENTILATOR", totalCount: 6, availableCount: 1 },
      { hospitalId: hospital1.id, type: "OXYGEN", totalCount: 20, availableCount: 9 },
    ])
    .returning(["id", "type"])
    .execute();

  await db
    .insertInto("beds")
    .values([
      { hospitalId: hospital2.id, type: "ICU", totalCount: 8, availableCount: 0 },
      { hospitalId: hospital2.id, type: "GENERAL", totalCount: 40, availableCount: 15 },
      { hospitalId: hospital2.id, type: "VENTILATOR", totalCount: 4, availableCount: 2 },
      { hospitalId: hospital2.id, type: "OXYGEN", totalCount: 15, availableCount: 6 },
    ])
    .execute();

  console.log("Creating doctors…");
  const doctor1 = await db
    .insertInto("doctors")
    .values({
      userId: doctorUser1.id,
      name: "Dr. Kavita Rao",
      specialty: "Cardiologist",
      city: "Ghaziabad",
      clinicName: "Sunshine Heart Clinic",
      address: "8 Nehru Nagar",
      consultationFee: 800,
      bio: "15 years treating heart conditions, focused on preventive cardiology.",
    })
    .returning(["id"])
    .executeTakeFirstOrThrow();

  const doctor2 = await db
    .insertInto("doctors")
    .values({
      userId: doctorUser2.id,
      name: "Dr. Arjun Mehta",
      specialty: "Dermatologist",
      city: "Ghaziabad",
      clinicName: "Skin & Glow Clinic",
      address: "22 Raj Nagar",
      consultationFee: 600,
      bio: "Specialist in acne, skin allergies, and cosmetic dermatology.",
    })
    .returning(["id"])
    .executeTakeFirstOrThrow();

  const doctor3 = await db
    .insertInto("doctors")
    .values({
      userId: doctorUser3.id,
      name: "Dr. Sana Iqbal",
      specialty: "Pediatrician",
      city: "Noida",
      clinicName: "Little Steps Clinic",
      address: "5 Sector 18",
      consultationFee: 500,
      bio: "Caring for infants and children for over a decade.",
    })
    .returning(["id"])
    .executeTakeFirstOrThrow();

  console.log("Creating upcoming slots…");
  function atTime(day: Date, hour: number, minute: number) {
    return setMilliseconds(setSeconds(setMinutes(setHours(day, hour), minute), 0), 0);
  }

  function slotsForDay(day: Date, doctorId: string) {
    const windows: [number, number][] = [
      [10, 13],
      [16, 19],
    ];
    const rows: { doctorId: string; startTime: Date; endTime: Date }[] = [];
    for (const [startHour, endHour] of windows) {
      let cursor = atTime(day, startHour, 0);
      const end = atTime(day, endHour, 0);
      while (cursor < end) {
        const slotEnd = new Date(cursor.getTime() + 30 * 60000);
        rows.push({ doctorId, startTime: cursor, endTime: slotEnd });
        cursor = slotEnd;
      }
    }
    return rows;
  }

  const doctorIds = [doctor1.id, doctor2.id, doctor3.id];
  const allSlots: { doctorId: string; startTime: Date; endTime: Date }[] = [];
  for (let i = 1; i <= 5; i++) {
    const day = addDays(new Date(), i);
    for (const doctorId of doctorIds) {
      allSlots.push(...slotsForDay(day, doctorId));
    }
  }
  await db.insertInto("doctorSlots").values(allSlots).execute();

  console.log("Creating a demo booked appointment…");
  const firstSlot = await db
    .selectFrom("doctorSlots")
    .selectAll()
    .where("doctorId", "=", doctor1.id)
    .orderBy("startTime")
    .executeTakeFirstOrThrow();

  await db.updateTable("doctorSlots").set({ isBooked: true }).where("id", "=", firstSlot.id).execute();
  await db
    .insertInto("appointments")
    .values({
      slotId: firstSlot.id,
      doctorId: doctor1.id,
      patientId: patient.id,
      patientName: "Aisha Verma",
      patientAge: 29,
      contactPhone: "9876500001",
      reason: "Routine checkup",
      status: "CONFIRMED",
    })
    .execute();

  console.log("Creating a demo pending bed reservation…");
  const icuBedH1 = bedsH1.find((b) => b.type === "ICU")!;
  await db
    .insertInto("bedReservations")
    .values({
      bedId: icuBedH1.id,
      hospitalId: hospital1.id,
      patientId: patient.id,
      patientName: "Rohit Verma",
      patientAge: 62,
      contactPhone: "9876500009",
      isEmergency: true,
      notes: "Chest pain, needs immediate ICU admission.",
      status: "PENDING",
    })
    .execute();

  console.log("\nDone. Demo accounts (all use password: " + DEMO_PASSWORD + "):");
  console.table([
    { role: "Patient", email: "patient@example.com" },
    { role: "Hospital admin (Sunrise, Ghaziabad)", email: "hospital1@example.com" },
    { role: "Hospital admin (Apex Care, Noida)", email: "hospital2@example.com" },
    { role: "Doctor (Cardiologist)", email: "doctor1@example.com" },
    { role: "Doctor (Dermatologist)", email: "doctor2@example.com" },
    { role: "Doctor (Pediatrician)", email: "doctor3@example.com" },
  ]);

  await db.destroy();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
