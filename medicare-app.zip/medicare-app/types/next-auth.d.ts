import { DefaultSession } from "next-auth";

export type AppRole = "PATIENT" | "HOSPITAL_ADMIN" | "DOCTOR";

declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      role: AppRole;
    } & DefaultSession["user"];
  }

  interface User {
    role: AppRole;
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    id: string;
    role: AppRole;
  }
}
